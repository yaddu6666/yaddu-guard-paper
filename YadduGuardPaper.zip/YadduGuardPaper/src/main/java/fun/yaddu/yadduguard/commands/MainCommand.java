package fun.yaddu.yadduguard.commands;

import fun.yaddu.yadduguard.YadduGuardPaper;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class MainCommand implements CommandExecutor {

    private final YadduGuardPaper plugin;

    public MainCommand(YadduGuardPaper plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("yadduguard.admin")) {
            sender.sendMessage(Component.text(plugin.getConfig().getString("messages.no-permission", "No permission!"), NamedTextColor.RED));
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.reload();
                sender.sendMessage(Component.text(
                        plugin.getConfig().getString("messages.reload-success", "Reloaded!"),
                        NamedTextColor.GREEN));
            }

            case "stats" -> {
                sender.sendMessage(Component.text("§6=== YadduGuard Paper Stats ===", NamedTextColor.GOLD));
                sender.sendMessage(Component.text("Online players: " + Bukkit.getOnlinePlayers().size(), NamedTextColor.AQUA));
                sender.sendMessage(Component.text("QuickFilter patterns: 200+", NamedTextColor.AQUA));
                sender.sendMessage(Component.text("AI Provider: " + plugin.getConfig().getString("ai.primary", "gemini"), NamedTextColor.AQUA));
                sender.sendMessage(Component.text("Discord: " + (plugin.getConfig().getBoolean("discord.enabled") ? "§aEnabled" : "§cDisabled"), NamedTextColor.AQUA));
            }

            case "unban" -> {
                if (args.length < 2) {
                    sender.sendMessage(Component.text("Usage: /ygpaper unban <player>", NamedTextColor.YELLOW));
                    return true;
                }
                // Remove temp ban
                plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
                    String uuid = null;
                    try (java.sql.Connection conn = plugin.getDatabaseManager().getConnection();
                         java.sql.PreparedStatement ps = conn.prepareStatement(
                                 "SELECT player_uuid FROM yg_tempbans WHERE player_name = ? LIMIT 1")) {
                        ps.setString(1, args[1]);
                        java.sql.ResultSet rs = ps.executeQuery();
                        if (rs.next()) uuid = rs.getString("player_uuid");
                    } catch (Exception e) {
                        plugin.getLogger().warning("Unban lookup failed: " + e.getMessage());
                    }
                    if (uuid != null) {
                        plugin.getDatabaseManager().removeTempBan(uuid);
                        final String finalUuid = uuid;
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                sender.sendMessage(Component.text("✅ Temp ban removed for " + args[1], NamedTextColor.GREEN)));
                    } else {
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                sender.sendMessage(Component.text("No temp ban found for " + args[1], NamedTextColor.YELLOW)));
                    }
                });
            }

            default -> sendHelp(sender);
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(Component.text("§6§l=== YadduGuard Paper v1.0.0 ===", NamedTextColor.GOLD));
        sender.sendMessage(Component.text("§e/ygpaper reload §7- Reload config", NamedTextColor.YELLOW));
        sender.sendMessage(Component.text("§e/ygpaper stats §7- Show plugin stats", NamedTextColor.YELLOW));
        sender.sendMessage(Component.text("§e/ygpaper unban <player> §7- Remove temp ban", NamedTextColor.YELLOW));
        sender.sendMessage(Component.text("§e/litban <player> [reason] §7- Shadow ban", NamedTextColor.YELLOW));
        sender.sendMessage(Component.text("§e/unlitban <player> §7- Remove shadow ban", NamedTextColor.YELLOW));
        sender.sendMessage(Component.text("§e/ymute <player> <min> [reason] §7- Mute", NamedTextColor.YELLOW));
        sender.sendMessage(Component.text("§e/yunmute <player> §7- Unmute", NamedTextColor.YELLOW));
        sender.sendMessage(Component.text("§e/yipban <player> [reason] §7- IP ban", NamedTextColor.YELLOW));
        sender.sendMessage(Component.text("§e/yhistory <player> §7- Violation history", NamedTextColor.YELLOW));
    }
}
