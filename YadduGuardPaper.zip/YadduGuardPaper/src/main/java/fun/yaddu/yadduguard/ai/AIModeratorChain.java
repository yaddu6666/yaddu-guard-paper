package fun.yaddu.yadduguard.ai;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import fun.yaddu.yadduguard.YadduGuardPaper;
import okhttp3.*;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class AIModeratorChain {

    private final YadduGuardPaper plugin;
    private OkHttpClient client;
    private final Gson gson = new Gson();

    private String geminiKey, groqKey, openaiKey;
    private String primaryProvider;
    private double confidenceThreshold;
    private int timeoutSeconds;

    private static final String SYSTEM_PROMPT = """
        You are a Minecraft chat moderation AI for an Indian gaming server called YadduNetwork.
        You understand Hindi, Hinglish (Hindi-English mix), and English.
        
        Analyze the given chat message and determine if it is toxic, abusive, or violates community rules.
        Toxic content includes: gaalis (abuse), harassment, threats, hate speech, extreme negativity.
        
        Normal competitive banter, GG, trash talk without slurs is usually fine.
        
        Respond ONLY with valid JSON in this exact format:
        {"toxic": true/false, "confidence": 0.0-1.0, "reason": "brief reason in English"}
        
        Do not include any other text or markdown.
        """;

    public AIModeratorChain(YadduGuardPaper plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        geminiKey = plugin.getConfig().getString("ai.gemini-key", "");
        groqKey = plugin.getConfig().getString("ai.groq-key", "");
        openaiKey = plugin.getConfig().getString("ai.openai-key", "");
        primaryProvider = plugin.getConfig().getString("ai.primary", "gemini");
        confidenceThreshold = plugin.getConfig().getDouble("ai.confidence-threshold", 0.75);
        timeoutSeconds = plugin.getConfig().getInt("ai.timeout-seconds", 5);

        client = new OkHttpClient.Builder()
                .connectTimeout(timeoutSeconds, TimeUnit.SECONDS)
                .readTimeout(timeoutSeconds, TimeUnit.SECONDS)
                .build();
    }

    /**
     * Synchronous AI check. Call from async thread only!
     * Returns AIResult with toxic flag and reason.
     */
    public AIResult moderate(String message) {
        String[] order = getProviderOrder();
        for (String provider : order) {
            try {
                AIResult result = callProvider(provider, message);
                if (result != null) return result;
            } catch (Exception e) {
                plugin.getLogger().warning("[AI] " + provider + " failed: " + e.getMessage() + " - trying next...");
            }
        }
        // All failed - fail safe (don't punish)
        return new AIResult(false, 0.0, "AI unavailable");
    }

    private String[] getProviderOrder() {
        return switch (primaryProvider.toLowerCase()) {
            case "groq" -> new String[]{"groq", "gemini", "openai"};
            case "openai" -> new String[]{"openai", "gemini", "groq"};
            default -> new String[]{"gemini", "groq", "openai"};
        };
    }

    private AIResult callProvider(String provider, String message) throws IOException {
        return switch (provider) {
            case "gemini" -> callGemini(message);
            case "groq" -> callGroq(message);
            case "openai" -> callOpenAI(message);
            default -> null;
        };
    }

    private AIResult callGemini(String message) throws IOException {
        if (geminiKey.isEmpty() || geminiKey.equals("YOUR_GEMINI_KEY")) return null;

        String url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + geminiKey;

        JsonObject part = new JsonObject();
        part.addProperty("text", SYSTEM_PROMPT + "\n\nMessage to analyze: " + message);

        JsonArray parts = new JsonArray();
        parts.add(part);

        JsonObject content = new JsonObject();
        content.add("parts", parts);

        JsonArray contents = new JsonArray();
        contents.add(content);

        JsonObject body = new JsonObject();
        body.add("contents", contents);

        Request request = new Request.Builder()
                .url(url)
                .post(RequestBody.create(gson.toJson(body), MediaType.get("application/json")))
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) return null;
            String responseBody = response.body().string();
            JsonObject json = gson.fromJson(responseBody, JsonObject.class);
            String text = json.getAsJsonArray("candidates")
                    .get(0).getAsJsonObject()
                    .getAsJsonObject("content")
                    .getAsJsonArray("parts")
                    .get(0).getAsJsonObject()
                    .get("text").getAsString();
            return parseAIResponse(text);
        }
    }

    private AIResult callGroq(String message) throws IOException {
        if (groqKey.isEmpty() || groqKey.equals("YOUR_GROQ_KEY")) return null;

        JsonObject systemMsg = new JsonObject();
        systemMsg.addProperty("role", "system");
        systemMsg.addProperty("content", SYSTEM_PROMPT);

        JsonObject userMsg = new JsonObject();
        userMsg.addProperty("role", "user");
        userMsg.addProperty("content", "Message to analyze: " + message);

        JsonArray messages = new JsonArray();
        messages.add(systemMsg);
        messages.add(userMsg);

        JsonObject body = new JsonObject();
        body.addProperty("model", "llama-3.1-8b-instant");
        body.add("messages", messages);
        body.addProperty("max_tokens", 150);
        body.addProperty("temperature", 0.1);

        Request request = new Request.Builder()
                .url("https://api.groq.com/openai/v1/chat/completions")
                .header("Authorization", "Bearer " + groqKey)
                .post(RequestBody.create(gson.toJson(body), MediaType.get("application/json")))
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) return null;
            String responseBody = response.body().string();
            JsonObject json = gson.fromJson(responseBody, JsonObject.class);
            String text = json.getAsJsonArray("choices")
                    .get(0).getAsJsonObject()
                    .getAsJsonObject("message")
                    .get("content").getAsString();
            return parseAIResponse(text);
        }
    }

    private AIResult callOpenAI(String message) throws IOException {
        if (openaiKey.isEmpty() || openaiKey.equals("YOUR_OPENAI_KEY")) return null;

        JsonObject systemMsg = new JsonObject();
        systemMsg.addProperty("role", "system");
        systemMsg.addProperty("content", SYSTEM_PROMPT);

        JsonObject userMsg = new JsonObject();
        userMsg.addProperty("role", "user");
        userMsg.addProperty("content", "Message to analyze: " + message);

        JsonArray messages = new JsonArray();
        messages.add(systemMsg);
        messages.add(userMsg);

        JsonObject body = new JsonObject();
        body.addProperty("model", "gpt-4o-mini");
        body.add("messages", messages);
        body.addProperty("max_tokens", 150);
        body.addProperty("temperature", 0.1);

        Request request = new Request.Builder()
                .url("https://api.openai.com/v1/chat/completions")
                .header("Authorization", "Bearer " + openaiKey)
                .post(RequestBody.create(gson.toJson(body), MediaType.get("application/json")))
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) return null;
            String responseBody = response.body().string();
            JsonObject json = gson.fromJson(responseBody, JsonObject.class);
            String text = json.getAsJsonArray("choices")
                    .get(0).getAsJsonObject()
                    .getAsJsonObject("message")
                    .get("content").getAsString();
            return parseAIResponse(text);
        }
    }

    private AIResult parseAIResponse(String text) {
        try {
            // Strip markdown code blocks if present
            text = text.replaceAll("```json|```", "").trim();
            JsonObject json = gson.fromJson(text, JsonObject.class);
            boolean toxic = json.get("toxic").getAsBoolean();
            double confidence = json.get("confidence").getAsDouble();
            String reason = json.get("reason").getAsString();

            if (toxic && confidence >= confidenceThreshold) {
                return new AIResult(true, confidence, reason);
            }
            return new AIResult(false, confidence, reason);
        } catch (Exception e) {
            plugin.getLogger().warning("[AI] Failed to parse response: " + text);
            return new AIResult(false, 0.0, "Parse error");
        }
    }

    public static class AIResult {
        public final boolean toxic;
        public final double confidence;
        public final String reason;

        public AIResult(boolean toxic, double confidence, String reason) {
            this.toxic = toxic;
            this.confidence = confidence;
            this.reason = reason;
        }
    }
}
