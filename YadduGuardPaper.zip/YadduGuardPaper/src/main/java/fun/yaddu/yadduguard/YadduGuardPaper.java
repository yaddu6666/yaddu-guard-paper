package fun.yaddu.yadduguard;

import fun.yaddu.yadduguard.ai.AIModeratorChain;
import fun.yaddu.yadduguard.commands.MainCommand;
import fun.yaddu.yadduguard.commands.ModerationCommands;
import fun.yaddu.yadduguard.database.DatabaseManager;
import fun.yaddu.yadduguard.discord.DiscordWebhook;
import fun.yaddu.yadduguard.filter.QuickFilter;
import fun.yaddu.yadduguard.listeners.ChatListener;
import fun.yaddu.yadduguard.listeners.PlayerJoinListener;
import fun.yaddu.yadduguard.punishment.PunishmentManager;
import org.bukkit.plugin.java.JavaPlugin;

public class YadduGuardPaper extends JavaPlugin {

    private static YadduGuardPaper instance;

    private DatabaseManager databaseManager;
    private QuickFilter quickFilter;
    private AIModeratorChain aiChain;
    private PunishmentManager punishmentManager;
    private DiscordWebhook discordWebhook;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        getLogger().info("╔══════════════════════════════════╗");
        getLogger().info("║   YadduGuard Paper  v1.0.0       ║");
        getLogger().info("║   YadduNetwork - Anti Abuse      ║");
        getLogger().info("╚══════════════════════════════════╝");

        // Init database
        databaseManager = new DatabaseManager(this);
        if (!databaseManager.init()) {
            getLogger().severe("MySQL connection failed! Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // Init modules
        quickFilter = new QuickFilter(this);
        aiChain = new AIModeratorChain(this);
        punishmentManager = new PunishmentManager(this);
        discordWebhook = new DiscordWebhook(this);

        // Register listeners
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerJoinListener(this), this);

        // Register commands
        getCommand("ygpaper").setExecutor(new MainCommand(this));
        ModerationCommands modCmds = new ModerationCommands(this);
        getCommand("litban").setExecutor(modCmds);
        getCommand("unlitban").setExecutor(modCmds);
        getCommand("ymute").setExecutor(modCmds);
        getCommand("yunmute").setExecutor(modCmds);
        getCommand("yipban").setExecutor(modCmds);
        getCommand("yhistory").setExecutor(modCmds);

        getLogger().info("YadduGuard Paper enabled! Bhai ab koi nahi bachega.");
    }

    @Override
    public void onDisable() {
        if (databaseManager != null) databaseManager.close();
        getLogger().info("YadduGuard Paper disabled.");
    }

    public void reload() {
        reloadConfig();
        quickFilter.reload();
        aiChain.reload();
        discordWebhook.reload();
    }

    // --- Getters ---
    public static YadduGuardPaper getInstance() { return instance; }
    public DatabaseManager getDatabaseManager() { return databaseManager; }
    public QuickFilter getQuickFilter() { return quickFilter; }
    public AIModeratorChain getAIChain() { return aiChain; }
    public PunishmentManager getPunishmentManager() { return punishmentManager; }
    public DiscordWebhook getDiscordWebhook() { return discordWebhook; }
}
