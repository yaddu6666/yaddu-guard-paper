package fun.yaddu.yadduguard.listeners;

import fun.yaddu.yadduguard.YadduGuardPaper;
import fun.yaddu.yadduguard.database.DatabaseManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;

public class PlayerJoinListener implements Listener {

    private final YadduGuardPaper plugin;

    public PlayerJoinListener(YadduGuardPaper plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onLogin(PlayerLoginEvent event) {
        String uuid = event.getPlayer().getUniqueId().toString();
        String ip = event.getAddress().getHostString();
        DatabaseManager db = plugin.getDatabaseManager();

        // IP ban check
        if (db.isIpBanned(ip)) {
            event.disallow(PlayerLoginEvent.Result.KICK_BANNED,
                    Component.text("🚫 Tera IP ban hai YadduNetwork se.\nContact: discord.yaddunetwork.com", NamedTextColor.DARK_RED));
            return;
        }

        // Temp ban check
        if (db.isTempBanned(uuid)) {
            String reason = db.getTempBanReason(uuid);
            event.disallow(PlayerLoginEvent.Result.KICK_BANNED,
                    Component.text("⏱ Temp Ban: " + reason, NamedTextColor.RED));
        }
    }
}
