package fun.yaddu.yadduguard.commands;

import fun.yaddu.yadduguard.YadduGuardPaper;
import fun.yaddu.yadduguard.database.DatabaseManager;
import fun.yaddu.yadduguard.punishment.PunishmentManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ModerationCommands implements CommandExecutor {

    private final YadduGuardPaper plugin;

    public ModerationCommands(YadduGuardPaper plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase()) {

            case "litban" -> {
                if (!sender.hasPermission("yadduguard.litban")) {
                    sender.sendMessage(Component.text(noPerms(), NamedTextColor.RED));
                    return true;
                }
                if (args.length < 1) { sender.sendMessage(Component.text("Usage: /litban <player> [reason]", NamedTextColor.YELLOW)); return true; }
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null) { sender.sendMessage(Component.text("Player not found or offline.", NamedTextColor.RED)); return true; }
                String reason = args.length > 1 ? String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)) : "Suspicious behavior";
                plugin.getPunishmentManager().applyLitBan(target, reason, sender.getName());
                sender.sendMessage(Component.text("✅ " + target.getName() + " shadow-banned. Reason: " + reason, NamedTextColor.GREEN));
                plugin.getDiscordWebhook().sendAdminAlert(sender.getName() + " shadow-banned " + target.getName() + " - " + reason);
            }

            case "unlitban" -> {
                if (!sender.hasPermission("yadduguard.litban")) {
                    sender.sendMessage(Component.text(noPerms(), NamedTextColor.RED));
                    return true;
                }
                if (args.length < 1) { sender.sendMessage(Component.text("Usage: /unlitban <player>", NamedTextColor.YELLOW)); return true; }
                Player target = Bukkit.getPlayer(args[0]);
                String uuid = target != null ? target.getUniqueId().toString() : getUUIDFromName(args[0]);
                if (uuid == null) { sender.sendMessage(Component.text("Player not found.", NamedTextColor.RED)); return true; }
                plugin.getDatabaseManager().removeLitBan(uuid);
                sender.sendMessage(Component.text("✅ Shadow ban removed for " + args[0], NamedTextColor.GREEN));
            }

            case "ymute" -> {
                if (!sender.hasPermission("yadduguard.mute")) {
                    sender.sendMessage(Component.text(noPerms(), NamedTextColor.RED));
                    return true;
                }
                if (args.length < 2) { sender.sendMessage(Component.text("Usage: /ymute <player> <minutes> [reason]", NamedTextColor.YELLOW)); return true; }
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null) { sender.sendMessage(Component.text("Player not found or offline.", NamedTextColor.RED)); return true; }
                int minutes;
                try { minutes = Integer.parseInt(args[1]); } catch (NumberFormatException e) { sender.sendMessage(Component.text("Invalid duration.", NamedTextColor.RED)); return true; }
                String reason = args.length > 2 ? String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length)) : "Manual mute by staff";
                long expires = System.currentTimeMillis() + (minutes * 60000L);
                plugin.getDatabaseManager().addMute(target.getUniqueId().toString(), target.getName(), reason, expires, sender.getName());
                target.sendMessage(Component.text("🔇 Tujhe " + minutes + " min ke liye mute kar diya. Reason: " + reason, NamedTextColor.RED));
                sender.sendMessage(Component.text("✅ " + target.getName() + " muted for " + minutes + " min.", NamedTextColor.GREEN));
            }

            case "yunmute" -> {
                if (!sender.hasPermission("yadduguard.mute")) {
                    sender.sendMessage(Component.text(noPerms(), NamedTextColor.RED));
                    return true;
                }
                if (args.length < 1) { sender.sendMessage(Component.text("Usage: /yunmute <player>", NamedTextColor.YELLOW)); return true; }
                Player target = Bukkit.getPlayer(args[0]);
                String uuid = target != null ? target.getUniqueId().toString() : getUUIDFromName(args[0]);
                if (uuid == null) { sender.sendMessage(Component.text("Player not found.", NamedTextColor.RED)); return true; }
                plugin.getDatabaseManager().removeMute(uuid);
                if (target != null) target.sendMessage(Component.text("✅ Tera mute hata diya gaya.", NamedTextColor.GREEN));
                sender.sendMessage(Component.text("✅ " + args[0] + " unmuted.", NamedTextColor.GREEN));
            }

            case "yipban" -> {
                if (!sender.hasPermission("yadduguard.ipban")) {
                    sender.sendMessage(Component.text(noPerms(), NamedTextColor.RED));
                    return true;
                }
                if (args.length < 1) { sender.sendMessage(Component.text("Usage: /yipban <player> [reason]", NamedTextColor.YELLOW)); return true; }
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null) { sender.sendMessage(Component.text("Player must be online for IP ban.", NamedTextColor.RED)); return true; }
                String ip = target.getAddress() != null ? target.getAddress().getHostString() : null;
                if (ip == null) { sender.sendMessage(Component.text("Could not get player IP.", NamedTextColor.RED)); return true; }
                String reason = args.length > 1 ? String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)) : "IP banned by staff";
                plugin.getDatabaseManager().addIpBan(ip, reason, sender.getName());
                target.kick(Component.text("🚫 IP Ban: " + reason, NamedTextColor.DARK_RED));
                sender.sendMessage(Component.text("✅ IP Banned: " + target.getName() + " (" + ip + ")", NamedTextColor.GREEN));
                plugin.getDiscordWebhook().sendAdminAlert(sender.getName() + " IP banned " + target.getName() + " (" + ip + ") - " + reason);
            }

            case "yhistory" -> {
                if (!sender.hasPermission("yadduguard.history")) {
                    sender.sendMessage(Component.text(noPerms(), NamedTextColor.RED));
                    return true;
                }
                if (args.length < 1) { sender.sendMessage(Component.text("Usage: /yhistory <player>", NamedTextColor.YELLOW)); return true; }
                showHistory(sender, args[0]);
            }
        }
        return true;
    }

    private void showHistory(CommandSender sender, String playerName) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            String sql = "SELECT message, reason, punishment, timestamp FROM yg_violations WHERE player_name = ? ORDER BY timestamp DESC LIMIT 10";
            try (Connection conn = plugin.getDatabaseManager().getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, playerName);
                ResultSet rs = ps.executeQuery();

                final StringBuilder sb = new StringBuilder();
                sb.append("§6=== YadduGuard History: §e").append(playerName).append(" §6===\n");
                int count = 0;
                while (rs.next()) {
                    count++;
                    String msg = rs.getString("message");
                    String reason = rs.getString("reason");
                    String punishment = rs.getString("punishment");
                    long ts = rs.getLong("timestamp");
                    java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM HH:mm");
                    sb.append("§7").append(count).append(". §c[").append(punishment).append("] §7")
                      .append(sdf.format(new java.util.Date(ts))).append(" - §f").append(reason).append("\n");
                }
                if (count == 0) sb.append("§aNo violations found!");

                final String output = sb.toString();
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    for (String line : output.split("\n")) {
                        sender.sendMessage(Component.text(line.replaceAll("§.", "")));
                    }
                });
            } catch (Exception e) {
                plugin.getLogger().warning("History query failed: " + e.getMessage());
            }
        });
    }

    private String getUUIDFromName(String name) {
        // Attempt offline UUID lookup from DB
        String sql = "SELECT player_uuid FROM yg_violations WHERE player_name = ? LIMIT 1";
        try (Connection conn = plugin.getDatabaseManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getString("player_uuid");
        } catch (Exception e) {
            plugin.getLogger().warning("UUID lookup failed: " + e.getMessage());
        }
        return null;
    }

    private String noPerms() {
        return plugin.getConfig().getString("messages.no-permission", "No permission!");
    }
}
