package fun.yaddu.yadduguard.punishment;

import fun.yaddu.yadduguard.YadduGuardPaper;
import fun.yaddu.yadduguard.database.DatabaseManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.Date;
import java.util.UUID;

public class PunishmentManager {

    private final YadduGuardPaper plugin;
    private final DatabaseManager db;

    public PunishmentManager(YadduGuardPaper plugin) {
        this.plugin = plugin;
        this.db = plugin.getDatabaseManager();
    }

    public enum PunishmentType {
        WARN, MUTE, KICK, TEMPBAN, IPBAN, JAIL
    }

    /**
     * Determine and apply escalating punishment based on violation count.
     */
    public PunishmentType punish(Player player, String reason) {
        String uuid = player.getUniqueId().toString();
        String name = player.getName();

        int violations = db.getViolationCount(uuid);
        int warnThreshold = plugin.getConfig().getInt("moderation.warn-threshold", 1);
        int muteThreshold = plugin.getConfig().getInt("moderation.mute-threshold", 2);
        int kickThreshold = plugin.getConfig().getInt("moderation.kick-threshold", 3);
        int tempbanThreshold = plugin.getConfig().getInt("moderation.tempban-threshold", 4);
        int ipbanThreshold = plugin.getConfig().getInt("moderation.ipban-threshold", 6);

        PunishmentType type;

        if (violations >= ipbanThreshold) {
            type = PunishmentType.IPBAN;
        } else if (violations >= tempbanThreshold) {
            type = PunishmentType.TEMPBAN;
        } else if (violations >= kickThreshold) {
            type = PunishmentType.KICK;
        } else if (violations >= muteThreshold) {
            type = PunishmentType.MUTE;
        } else {
            type = PunishmentType.WARN;
        }

        // Record the violation first
        db.addViolation(uuid, name, "-", reason, type.name());

        // Apply punishment
        applyPunishment(player, type, reason);
        return type;
    }

    public void applyPunishment(Player player, PunishmentType type, String reason) {
        String uuid = player.getUniqueId().toString();
        String name = player.getName();
        int muteDuration = plugin.getConfig().getInt("moderation.mute-duration-minutes", 30);
        int tempbanDuration = plugin.getConfig().getInt("moderation.tempban-duration-minutes", 1440);

        switch (type) {
            case WARN -> {
                player.sendMessage(Component.text("⚠ Chetavni: " + reason, NamedTextColor.YELLOW));
            }
            case MUTE -> {
                long expiresAt = System.currentTimeMillis() + (muteDuration * 60000L);
                db.addMute(uuid, name, reason, expiresAt, "YadduGuard");
                player.sendMessage(Component.text("🔇 Tujhe " + muteDuration + " minutes ke liye mute kar diya. Reason: " + reason, NamedTextColor.RED));
            }
            case KICK -> {
                String msg = plugin.getConfig().getString("messages.kicked", "&cTujhe kick kar diya gaya.")
                        .replace("{reason}", reason).replace("&c", "");
                player.kick(Component.text(msg, NamedTextColor.RED));
            }
            case TEMPBAN -> {
                long expiresAt = System.currentTimeMillis() + (tempbanDuration * 60000L);
                db.addTempBan(uuid, name, reason, expiresAt, "YadduGuard");
                player.kick(Component.text("🚫 Temp Ban: " + reason + "\nExpires in: " + tempbanDuration + " minutes", NamedTextColor.DARK_RED));
            }
            case IPBAN -> {
                String ip = player.getAddress() != null ? player.getAddress().getHostString() : "unknown";
                db.addIpBan(ip, reason, "YadduGuard");
                Bukkit.getBanList(BanList.Type.IP).addBan(ip, reason, (Date) null, "YadduGuard");
                player.kick(Component.text("🚫 IP Ban: " + reason, NamedTextColor.DARK_RED));
            }
            case JAIL -> {
                applyJail(player);
                player.sendMessage(Component.text("⛓ Tu jail mein hai bhai. Reason: " + reason, NamedTextColor.DARK_RED));
            }
        }
    }

    /**
     * Apply lit ban (shadow ban) - player sees their own messages, others don't.
     */
    public void applyLitBan(Player player, String reason, String bannedBy) {
        db.addLitBan(player.getUniqueId().toString(), player.getName(), reason, bannedBy);
        plugin.getLogger().info("[LitBan] " + player.getName() + " shadow-banned by " + bannedBy + " - Reason: " + reason);
    }

    public void removeLitBan(String uuid) {
        db.removeLitBan(uuid);
    }

    public boolean isLitBanned(UUID uuid) {
        return db.isLitBanned(uuid.toString());
    }

    public boolean isMuted(UUID uuid) {
        return db.isMuted(uuid.toString());
    }

    public String getMuteReason(UUID uuid) {
        return db.getMuteReason(uuid.toString());
    }

    private void applyJail(Player player) {
        if (!plugin.getConfig().getBoolean("moderation.jail-enabled", false)) return;
        String world = plugin.getConfig().getString("moderation.jail-location.world", "world");
        double x = plugin.getConfig().getDouble("moderation.jail-location.x", 0.5);
        double y = plugin.getConfig().getDouble("moderation.jail-location.y", 64.0);
        double z = plugin.getConfig().getDouble("moderation.jail-location.z", 0.5);
        org.bukkit.World w = Bukkit.getWorld(world);
        if (w != null) player.teleport(new Location(w, x, y, z));
    }
}
