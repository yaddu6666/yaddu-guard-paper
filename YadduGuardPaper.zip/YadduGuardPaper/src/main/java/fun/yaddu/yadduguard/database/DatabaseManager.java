package fun.yaddu.yadduguard.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import fun.yaddu.yadduguard.YadduGuardPaper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

public class DatabaseManager {

    private final YadduGuardPaper plugin;
    private HikariDataSource dataSource;
    private final Logger log;

    public DatabaseManager(YadduGuardPaper plugin) {
        this.plugin = plugin;
        this.log = plugin.getLogger();
    }

    public boolean init() {
        try {
            HikariConfig config = new HikariConfig();
            config.setJdbcUrl(String.format("jdbc:mysql://%s:%d/%s?useSSL=false&autoReconnect=true&characterEncoding=utf8",
                    plugin.getConfig().getString("mysql.host"),
                    plugin.getConfig().getInt("mysql.port"),
                    plugin.getConfig().getString("mysql.database")));
            config.setUsername(plugin.getConfig().getString("mysql.username"));
            config.setPassword(plugin.getConfig().getString("mysql.password"));
            config.setMaximumPoolSize(plugin.getConfig().getInt("mysql.pool-size", 10));
            config.setConnectionTimeout(10000);
            config.setPoolName("YadduGuard-Pool");

            dataSource = new HikariDataSource(config);
            createTables();
            log.info("MySQL connected successfully!");
            return true;
        } catch (Exception e) {
            log.severe("MySQL init failed: " + e.getMessage());
            return false;
        }
    }

    private void createTables() throws SQLException {
        try (Connection conn = getConnection()) {
            // Violations table
            conn.prepareStatement("""
                CREATE TABLE IF NOT EXISTS yg_violations (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    player_uuid VARCHAR(36) NOT NULL,
                    player_name VARCHAR(16) NOT NULL,
                    message TEXT NOT NULL,
                    reason VARCHAR(100) NOT NULL,
                    punishment VARCHAR(50) NOT NULL,
                    timestamp BIGLONG NOT NULL,
                    INDEX idx_uuid (player_uuid)
                )
            """).executeUpdate();

            // Mutes table
            conn.prepareStatement("""
                CREATE TABLE IF NOT EXISTS yg_mutes (
                    player_uuid VARCHAR(36) PRIMARY KEY,
                    player_name VARCHAR(16) NOT NULL,
                    reason VARCHAR(255),
                    expires_at BIGINT NOT NULL,
                    muted_by VARCHAR(16) NOT NULL
                )
            """).executeUpdate();

            // IP Bans table
            conn.prepareStatement("""
                CREATE TABLE IF NOT EXISTS yg_ipbans (
                    ip VARCHAR(45) PRIMARY KEY,
                    reason VARCHAR(255),
                    banned_by VARCHAR(16) NOT NULL,
                    timestamp BIGINT NOT NULL
                )
            """).executeUpdate();

            // Lit bans (shadow bans) table
            conn.prepareStatement("""
                CREATE TABLE IF NOT EXISTS yg_litbans (
                    player_uuid VARCHAR(36) PRIMARY KEY,
                    player_name VARCHAR(16) NOT NULL,
                    reason VARCHAR(255),
                    banned_by VARCHAR(16) NOT NULL,
                    timestamp BIGINT NOT NULL
                )
            """).executeUpdate();

            // Temp bans table
            conn.prepareStatement("""
                CREATE TABLE IF NOT EXISTS yg_tempbans (
                    player_uuid VARCHAR(36) PRIMARY KEY,
                    player_name VARCHAR(16) NOT NULL,
                    reason VARCHAR(255),
                    expires_at BIGINT NOT NULL,
                    banned_by VARCHAR(16) NOT NULL
                )
            """).executeUpdate();

            log.info("All YadduGuard tables created/verified.");
        }
    }

    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    // =================== VIOLATIONS ===================

    public void addViolation(String uuid, String name, String message, String reason, String punishment) {
        String sql = "INSERT INTO yg_violations (player_uuid, player_name, message, reason, punishment, timestamp) VALUES (?,?,?,?,?,?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ps.setString(2, name);
            ps.setString(3, message);
            ps.setString(4, reason);
            ps.setString(5, punishment);
            ps.setLong(6, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException e) {
            log.warning("Failed to add violation: " + e.getMessage());
        }
    }

    public int getViolationCount(String uuid) {
        String sql = "SELECT COUNT(*) FROM yg_violations WHERE player_uuid = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            log.warning("Failed to get violation count: " + e.getMessage());
        }
        return 0;
    }

    // =================== MUTES ===================

    public void addMute(String uuid, String name, String reason, long expiresAt, String mutedBy) {
        String sql = "REPLACE INTO yg_mutes (player_uuid, player_name, reason, expires_at, muted_by) VALUES (?,?,?,?,?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ps.setString(2, name);
            ps.setString(3, reason);
            ps.setLong(4, expiresAt);
            ps.setString(5, mutedBy);
            ps.executeUpdate();
        } catch (SQLException e) {
            log.warning("Failed to add mute: " + e.getMessage());
        }
    }

    public boolean isMuted(String uuid) {
        String sql = "SELECT expires_at FROM yg_mutes WHERE player_uuid = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                long expires = rs.getLong("expires_at");
                if (expires == -1) return true; // permanent
                if (System.currentTimeMillis() < expires) return true;
                // expired, remove
                removeMute(uuid);
            }
        } catch (SQLException e) {
            log.warning("Failed to check mute: " + e.getMessage());
        }
        return false;
    }

    public String getMuteReason(String uuid) {
        String sql = "SELECT reason FROM yg_mutes WHERE player_uuid = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getString("reason");
        } catch (SQLException e) {
            log.warning("Failed to get mute reason: " + e.getMessage());
        }
        return "Anti-abuse system";
    }

    public void removeMute(String uuid) {
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM yg_mutes WHERE player_uuid = ?")) {
            ps.setString(1, uuid);
            ps.executeUpdate();
        } catch (SQLException e) {
            log.warning("Failed to remove mute: " + e.getMessage());
        }
    }

    // =================== LIT BANS ===================

    public void addLitBan(String uuid, String name, String reason, String bannedBy) {
        String sql = "REPLACE INTO yg_litbans (player_uuid, player_name, reason, banned_by, timestamp) VALUES (?,?,?,?,?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ps.setString(2, name);
            ps.setString(3, reason);
            ps.setString(4, bannedBy);
            ps.setLong(5, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException e) {
            log.warning("Failed to add litban: " + e.getMessage());
        }
    }

    public boolean isLitBanned(String uuid) {
        String sql = "SELECT player_uuid FROM yg_litbans WHERE player_uuid = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            log.warning("Failed to check litban: " + e.getMessage());
        }
        return false;
    }

    public void removeLitBan(String uuid) {
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM yg_litbans WHERE player_uuid = ?")) {
            ps.setString(1, uuid);
            ps.executeUpdate();
        } catch (SQLException e) {
            log.warning("Failed to remove litban: " + e.getMessage());
        }
    }

    // =================== IP BANS ===================

    public void addIpBan(String ip, String reason, String bannedBy) {
        String sql = "REPLACE INTO yg_ipbans (ip, reason, banned_by, timestamp) VALUES (?,?,?,?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, ip);
            ps.setString(2, reason);
            ps.setString(3, bannedBy);
            ps.setLong(4, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException e) {
            log.warning("Failed to add IP ban: " + e.getMessage());
        }
    }

    public boolean isIpBanned(String ip) {
        String sql = "SELECT ip FROM yg_ipbans WHERE ip = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, ip);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            log.warning("Failed to check IP ban: " + e.getMessage());
        }
        return false;
    }

    // =================== TEMP BANS ===================

    public void addTempBan(String uuid, String name, String reason, long expiresAt, String bannedBy) {
        String sql = "REPLACE INTO yg_tempbans (player_uuid, player_name, reason, expires_at, banned_by) VALUES (?,?,?,?,?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ps.setString(2, name);
            ps.setString(3, reason);
            ps.setLong(4, expiresAt);
            ps.setString(5, bannedBy);
            ps.executeUpdate();
        } catch (SQLException e) {
            log.warning("Failed to add temp ban: " + e.getMessage());
        }
    }

    public boolean isTempBanned(String uuid) {
        String sql = "SELECT expires_at FROM yg_tempbans WHERE player_uuid = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                long expires = rs.getLong("expires_at");
                if (System.currentTimeMillis() < expires) return true;
                removeTempBan(uuid);
            }
        } catch (SQLException e) {
            log.warning("Failed to check temp ban: " + e.getMessage());
        }
        return false;
    }

    public String getTempBanReason(String uuid) {
        String sql = "SELECT reason, expires_at FROM yg_tempbans WHERE player_uuid = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                long remaining = (rs.getLong("expires_at") - System.currentTimeMillis()) / 60000;
                return rs.getString("reason") + " | " + remaining + " minutes remaining";
            }
        } catch (SQLException e) {
            log.warning("Failed to get temp ban reason: " + e.getMessage());
        }
        return "Temporary ban";
    }

    public void removeTempBan(String uuid) {
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM yg_tempbans WHERE player_uuid = ?")) {
            ps.setString(1, uuid);
            ps.executeUpdate();
        } catch (SQLException e) {
            log.warning("Failed to remove temp ban: " + e.getMessage());
        }
    }

    public void close() {
        if (dataSource != null && !dataSource.isClosed()) dataSource.close();
    }
}
