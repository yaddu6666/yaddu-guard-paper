package fun.yaddu.yadduguard.filter;

import fun.yaddu.yadduguard.YadduGuardPaper;

import java.util.Set;
import java.util.regex.Pattern;

public class QuickFilter {

    private final YadduGuardPaper plugin;

    // === Hindi / Hinglish gaali patterns ===
    private static final Set<String> GAALI_PATTERNS = Set.of(
        // BC / MC variants
        "bc", "bsdk", "bsdke", "bsdki", "bsdi", "bhsdk", "bhsdke", "bhsdi",
        "mc", "mchod", "mchuda", "mchodi",
        // Madarchod variants
        "madarchod", "madarch0d", "m4darchod", "maadarcho", "madarcho",
        "madar", "maadar", "m4dar",
        // Bhenchod variants
        "bhenchod", "bhenchod", "bhench0d", "bhencho", "bhen", "ben",
        "bhn", "bhench", "bhanchod", "bhancho",
        // Chutiya variants
        "chutiya", "chutiye", "chut", "ch0t", "choot", "chutiye",
        "chutyia", "chutiay", "chutia", "c h u t",
        // Gaand variants
        "gaand", "gand", "g4nd", "gaandu", "gandu", "gaandmara",
        "gaandmarao", "gandu",
        // Randi variants
        "randi", "r4ndi", "randibaaz", "randa",
        // Harami / Haramkhor
        "harami", "haramkhor", "haramzada", "haramzadi", "haram",
        "haramzade",
        // Kamina / Kameena
        "kamina", "kameena", "kamine",
        // Lund variants
        "lund", "l0nd", "loda", "loda", "louda",
        // Tatti / Sala
        "tatti", "tattu", "sala", "saala", "saale", "saali",
        // Other common
        "kutte", "kutta", "kutiya", "kutiya", "bakwas",
        "bevkoof", "bewkoof", "bewkuf", "ullu", "ulloo",
        "gadha", "gadhe", "gadhi", "donkey",
        "chhinal", "chhinar", "suar", "suwar",
        "nalayak", "nikamma",
        // English gaalis
        "fuck", "fuk", "f*ck", "f**k", "fucc", "fxck",
        "shit", "sh1t", "sh!t", "shitt",
        "bitch", "b1tch", "b!tch", "biatch",
        "asshole", "a**hole", "azzhole",
        "bastard", "bastar",
        "whore", "wh0re",
        "cunt", "c*nt",
        "nigga", "nigger", "n1gga",
        "dick", "d1ck", "dyck",
        "cock", "c0ck",
        "pussy", "puss1",
        "retard", "ret4rd",
        "idiot", "idi0t",
        "slut", "sl*t",
        "damn", "dammit",
        "hell",
        "motherfucker", "mf",
        // Spacey bypasses
        "f u c k", "s h i t", "b i t c h",
        "c h u t i y a", "b h e n c h o d"
    );

    // Pre-compile a pattern for leet speak normalization
    private static final Pattern LEET_NORMALIZE = Pattern.compile(
        "[@]|[4]|[3]|[1!]|[0]|[5$]|[7]",
        Pattern.CASE_INSENSITIVE
    );

    // Strip spaces/dots/underscores between chars (bypass detection)
    private static final Pattern BYPASS_STRIP = Pattern.compile("[\\s.\\-_*]+");

    public QuickFilter(YadduGuardPaper plugin) {
        this.plugin = plugin;
    }

    public void reload() {
        // Nothing to reload, static patterns
    }

    /**
     * Returns true if message contains a flagged pattern.
     */
    public boolean isFlagged(String message) {
        String normalized = normalize(message);
        for (String pattern : GAALI_PATTERNS) {
            if (normalized.contains(pattern)) return true;
        }
        return false;
    }

    /**
     * Returns the matched pattern for logging, or null.
     */
    public String getMatchedPattern(String message) {
        String normalized = normalize(message);
        for (String pattern : GAALI_PATTERNS) {
            if (normalized.contains(pattern)) return pattern;
        }
        return null;
    }

    private String normalize(String input) {
        // Lowercase
        String s = input.toLowerCase();
        // Strip bypass chars
        s = BYPASS_STRIP.matcher(s).replaceAll("");
        // Normalize leet speak
        s = s.replace("@", "a")
             .replace("4", "a")
             .replace("3", "e")
             .replace("1", "i")
             .replace("!", "i")
             .replace("0", "o")
             .replace("5", "s")
             .replace("$", "s")
             .replace("7", "t");
        return s;
    }
}
