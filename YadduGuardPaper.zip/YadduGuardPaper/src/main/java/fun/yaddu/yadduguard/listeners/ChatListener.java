package fun.yaddu.yadduguard.listeners;

import fun.yaddu.yadduguard.YadduGuardPaper;
import fun.yaddu.yadduguard.ai.AIModeratorChain;
import fun.yaddu.yadduguard.punishment.PunishmentManager;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

public class ChatListener implements Listener {

    private final YadduGuardPaper plugin;

    public ChatListener(YadduGuardPaper plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        String message = PlainTextComponentSerializer.plainText().serialize(event.message());
        String uuid = player.getUniqueId().toString();
        PunishmentManager pm = plugin.getPunishmentManager();

        // Bypass check - admins skip moderation
        if (player.hasPermission("yadduguard.bypass")) return;

        // --- LIT BAN: Cancel broadcast, player sees own message only ---
        if (pm.isLitBanned(player.getUniqueId())) {
            event.viewers().removeIf(audience -> audience != player);
            // Player sees a fake confirmation
            String notice = plugin.getConfig().getString("messages.litbanned-notice", "&aMessage sent!");
            // Message already "delivered" to themselves, just let it pass to them
            return;
        }

        // --- MUTE CHECK ---
        if (pm.isMuted(player.getUniqueId())) {
            event.setCancelled(true);
            String reason = pm.getMuteReason(player.getUniqueId());
            String msg = plugin.getConfig().getString("messages.muted", "&cMuted: {reason}")
                    .replace("{reason}", reason)
                    .replace("&c", "")
                    .replace("&a", "");
            player.sendMessage(net.kyori.adventure.text.Component.text("🔇 " + msg,
                    net.kyori.adventure.text.format.NamedTextColor.RED));
            return;
        }

        // --- QUICKFILTER CHECK ---
        if (plugin.getQuickFilter().isFlagged(message)) {
            event.setCancelled(true);
            String matched = plugin.getQuickFilter().getMatchedPattern(message);
            String reason = "QuickFilter: gaali detected (" + matched + ")";

            // Punish on main thread
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                PunishmentManager.PunishmentType type = pm.punish(player, reason);
                plugin.getDiscordWebhook().sendViolationAlert(player.getName(), message, reason, type.name());
            });
            return;
        }

        // --- AI CHECK (async, non-blocking) ---
        boolean quickfilterOnly = plugin.getConfig().getBoolean("moderation.quickfilter-only", false);
        if (!quickfilterOnly) {
            // Already on async thread (AsyncChatEvent), safe to call AI
            AIModeratorChain.AIResult result = plugin.getAIChain().moderate(message);

            if (result.toxic) {
                event.setCancelled(true);
                String reason = "AI (" + String.format("%.0f", result.confidence * 100) + "%): " + result.reason;

                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    PunishmentManager.PunishmentType type = pm.punish(player, reason);
                    plugin.getDiscordWebhook().sendViolationAlert(player.getName(), message, reason, type.name());
                });
            }
        }
    }
}
