package fun.yaddu.yadduguard.discord;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import fun.yaddu.yadduguard.YadduGuardPaper;
import okhttp3.*;

import java.io.IOException;

public class DiscordWebhook {

    private final YadduGuardPaper plugin;
    private OkHttpClient client;
    private String webhookUrl;
    private boolean enabled;
    private int alertColor;

    public DiscordWebhook(YadduGuardPaper plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        enabled = plugin.getConfig().getBoolean("discord.enabled", true);
        webhookUrl = plugin.getConfig().getString("discord.webhook-url", "");
        alertColor = plugin.getConfig().getInt("discord.alert-color", 16711680);
        client = new OkHttpClient();
    }

    public void sendViolationAlert(String playerName, String message, String reason, String punishment) {
        if (!enabled || webhookUrl.isEmpty() || webhookUrl.equals("YOUR_DISCORD_WEBHOOK")) return;

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                JsonObject embed = new JsonObject();
                embed.addProperty("title", "🚨 Chat Violation - YadduGuard Paper");
                embed.addProperty("color", alertColor);
                embed.addProperty("description", "**Player:** `" + playerName + "`\n" +
                        "**Message:** `" + message + "`\n" +
                        "**Reason:** " + reason + "\n" +
                        "**Action:** `" + punishment + "`");

                JsonObject footer = new JsonObject();
                footer.addProperty("text", "YadduNetwork • YadduGuard Paper");
                embed.add("footer", footer);

                JsonArray embeds = new JsonArray();
                embeds.add(embed);

                JsonObject body = new JsonObject();
                body.add("embeds", embeds);
                body.addProperty("username", "YadduGuard");

                Request request = new Request.Builder()
                        .url(webhookUrl)
                        .post(RequestBody.create(body.toString(), MediaType.get("application/json")))
                        .build();

                client.newCall(request).execute().close();
            } catch (IOException e) {
                plugin.getLogger().warning("[Discord] Webhook failed: " + e.getMessage());
            }
        });
    }

    public void sendAdminAlert(String message) {
        if (!enabled || webhookUrl.isEmpty() || webhookUrl.equals("YOUR_DISCORD_WEBHOOK")) return;

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                JsonObject body = new JsonObject();
                body.addProperty("content", "**[YadduGuard]** " + message);
                body.addProperty("username", "YadduGuard");

                Request request = new Request.Builder()
                        .url(webhookUrl)
                        .post(RequestBody.create(body.toString(), MediaType.get("application/json")))
                        .build();

                client.newCall(request).execute().close();
            } catch (IOException e) {
                plugin.getLogger().warning("[Discord] Webhook failed: " + e.getMessage());
            }
        });
    }
}
