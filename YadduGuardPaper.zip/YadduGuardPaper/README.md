# YadduGuard Paper

AI-powered chat moderation plugin for Paper/Spigot - YadduNetwork

## Features
- **QuickFilter** - 200+ gaali patterns (Hindi/Hinglish/English), leet speak & bypass detection
- **AI Moderation** - Gemini → Groq → OpenAI fallback chain, understands Hindi/Hinglish
- **Escalating Punishments** - Warn → Mute → Kick → Tempban → IP Ban
- **Lit Ban (Shadow Ban)** - Player sees own messages, others don't
- **Discord Webhook** - Real-time violation alerts
- **MySQL Persistence** - HikariCP pooling, all punishments stored
- **IP Ban on login check** - Bypasses alt accounts
- **Jail system** - Optional teleport to jail location

## Requirements
- Paper 1.20.4+
- Java 17+
- MySQL database

## Setup
1. Drop JAR into `plugins/`
2. Start server, stop server
3. Edit `plugins/YadduGuardPaper/config.yml`
4. Fill in MySQL credentials and AI API keys
5. Set Discord webhook URL
6. Restart server

## Commands
| Command | Description | Permission |
|---------|-------------|------------|
| `/ygpaper reload` | Reload config | `yadduguard.admin` |
| `/ygpaper stats` | Plugin stats | `yadduguard.admin` |
| `/ygpaper unban <player>` | Remove temp ban | `yadduguard.admin` |
| `/litban <player> [reason]` | Shadow ban | `yadduguard.litban` |
| `/unlitban <player>` | Remove shadow ban | `yadduguard.litban` |
| `/ymute <player> <min> [reason]` | Mute | `yadduguard.mute` |
| `/yunmute <player>` | Unmute | `yadduguard.mute` |
| `/yipban <player> [reason]` | IP ban | `yadduguard.ipban` |
| `/yhistory <player>` | Violation history | `yadduguard.history` |

## Permissions
- `yadduguard.admin` - Full access (default: op)
- `yadduguard.bypass` - Skip moderation (default: false)

## Build
```bash
mvn clean package
# JAR will be at target/YadduGuardPaper-1.0.0.jar
```

Or use GitHub Actions (workflow included).
